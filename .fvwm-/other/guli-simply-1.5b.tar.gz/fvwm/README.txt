#############################################################################
#
# 	 Guli-simply	(Guli-Simply-v1.5.tar.gz are full theme with wallpapers, icons...,)
#	 V. 1.5 (only in folder "Guli-Simply/"   
#	 By Gulivert
#	 Display 1784x1344x24 / 75Mhz
#	 02.01.2005 / 11:30
#	 gulivert@bluewin.ch
#	 http://clan-hash.com/~guli/fvwm
#	 partner : http://www.as.ua.edu/~flux/fvwm/
#
#############################################################################
#
# VERSION 1.5 Change log
# Add border 1 pixel on window
# Add New menu on Gulidock (menu Update for Gentoo and Root menu)
# Add new application launcher in Gulidock
# Add menu Exit Fvwm
# Correction script FvwmApllet-Digitalclock
# Add mouse wheel for shade unshade window
# 
# Remove mini-dock  (from version 1.4)
# Replace Evolution by Thundebird in menu entrie
# Correction Windows Border for problems
#
#############################################################################
#
# VERSION 1.4 Change log
# add min-dock with new icons in folder "Guli-Simply/icons-dock"
# add MWM emulation for style (Xmms, mplayer, xine, etc ...)
# modified the entries of the menu (new and delete)
# add two buttons for set transparency or opaque
# new decoration "Rmilk" in folder "Guli-Simply/decorations/"
#
#############################################################################
#
# VERSION 1.3 Change log
# add new dock in upper right (Guli-dock Version 1.1)
# add multi-desk ,multi wallpapers and new pager config ;o)
# Add script settrans.pl and new module FvwmTransset (Forum Gentoo Thread The F... Virtual Desktop)
# Very thanks Forum Gentoo French and English for the threads FVWM
# You can look this forum here
# http://forums.gentoo.org/viewtopic.php?t=189895	(FRENCH)
# and
# http://forums.gentoo.org/viewtopic.php?t=80517	(ENGLISH)
#
#############################################################################

First, great thank's to Taviso, Ikaro and Desintegr for their website and
for the fileconfig's examples. I couldn't achieve this without them.
So thank's again. You'll find their site with their configurations, decorations,... 
at this address :

    Desintegr : http://desintegr.free.fr/?page=linux/fvwm
    Ikaro : http://ikaro.dk
    Taviso : http://dev.gentoo.org/~taviso/

Please, excuse me, because I didn't mention their names in my first
theme that I put on the net. This was a mistake from me, because it 
was clearly inspired from them. So I do my best to personalize my 
theme and for that, I recommand to all the fvwm's official FAQ and of course, 
the good old man NameModule which got some precious informations.

http://www.fvwm.org/documentation/faq/

I===========================================
Installation
I===========================================

  1.-

Create a folder "theme-fvwm" at your home's root.
Copy inside the directories:

    - configs
    - decorations
    - icons
    - modules	---> Only if you are Xorg 6.8 or cvs with xcompmgr and transset
    - pager
    - scripts
    - splash
    - wallpapers
I===========================================

  2.- 

Copy the file "fvwm2rc" in "~/.fvwm/", and don't forget to rename it in ".fvwm2rc"
and copy inside the files in "~/.fvwm/"

    - trans.defaults	---> Only if you are Xorg 6.8 or cvs with xcompmgr and transset
    - trans.temp 	---> Only if you are Xorg 6.8 or cvs with xcompmgr and transset
I===========================================

  3.- Only if you are Xorg 6.8 or cvs with xcompmgr and transset

Copy modules in /usr/lib/Fvwm/Version/

    - FvwmTransset
    - FvwmTransfocus

and chmod a+x /usr/lib/Fvwm/Version/FvwmTransset and FvwmTransfocus
I===========================================

Start FVWM again ;o)

I===========================================
