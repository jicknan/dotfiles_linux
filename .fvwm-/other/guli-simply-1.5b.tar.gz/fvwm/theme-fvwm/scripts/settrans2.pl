#!/usr/bin/perl

# Arguments:
# 1) A window ID in hex or decimal
# 2) Either "+" or "-" (without quotes)
# Indicates direction of transparency stepping,
# and steps by 5
# + Means make more transparent ($trans -= 5)
# - Means make less transparent ($trans += 5)

my $win_id = @ARGV[0];
$win_id = oct($win_id) if $win_id =~ /^0/;
my $direction = @ARGV[1];
my $tempFile = ".fvwm/trans.temp";

if((($direction ne "+") && ($direction ne "-")))
{
 die "Wrong arguments\n";
}

chdir;
open(TEMP, "<", $tempFile);

# Transparency levels keyed by window ID
my %transHash;

while(my $line = <TEMP>)
{
 chomp($line);
 my @temp = split(/:/, $line);
 $transHash{@temp[0]} = @temp[1];
}

close(TEMP);


# Make less transparent
if($direction eq "-")
{
 # If the window isn't transparent (according to temp file)
 # then just quit out (die), since it can't really be less transparent
 if(!defined($transHash{$win_id}))
 {
  die $win_id . " already fully opaque\n";
 }

 $trans = $transHash{$win_id};
 
 if($trans < 1.0)
 {
  $trans += 0.25;
 }
}
# Make more transparent
else
{
 if(!defined($transHash{$win_id}))
 {
  $trans = 0.75;
 }
 else
 {
  $trans = $transHash{$win_id};
   
  if($trans > 0.1)
  {
   $trans -= 0.25;
  }
 }
}

my $cmd = "transset " . $trans . " -id " . $win_id;
system($cmd);

# Update the hash with the new value
$transHash{$win_id} = $trans;

open(TEMP, ">", $tempFile);


# Re-output the whole temp file, with new value
my @keys = keys %transHash;
my @values = values %transHash;

while(@keys)
{
 my $temp = pop(@keys) . ":" . pop(@values) . "\n";
 print TEMP $temp;
}

close(TEMP); 
