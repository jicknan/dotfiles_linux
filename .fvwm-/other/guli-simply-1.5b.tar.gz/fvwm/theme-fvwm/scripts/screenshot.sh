#!/bin/bash
#import -window root ${FNAME}.${EXT}

NOW=`date '+%Y%m%d'`
FNAME=fvwm${NOW}
EXT=xpm

cd /home/gulivert/

sleep 5

xwd -root > ${FNAME}.${EXT}

convert -resize 400x300 ${FNAME}.${EXT} fvwm${NOW}_thumb.${EXT}



